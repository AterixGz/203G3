import { useState } from 'react'
import PurchaseOrder from './PurchaseOrder/PurchaseOrder'
import Requisition from "./Requisition/Requisition";
import POReceipt from './POReceipt/ poreceipt';
import Invoice from './Invoice/Invoice';
import ApBalance from './Apbalance/Apbalance';
import Payment from './Payment/Payment';
import ApBalanceAfter from './Apbalanceafter/Apbalanceafter';
import './App.css'




function App() {
  const [count, setCount] = useState(0)

  return (
    <>
    <Requisition/>
    <PurchaseOrder/>
    <POReceipt/>
    <Invoice/>
    <ApBalance/>
    <Payment/>
    <ApBalanceAfter/>
    </>
  )
}

export default App
